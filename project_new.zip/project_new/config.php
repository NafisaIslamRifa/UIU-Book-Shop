<?php

$conn = mysqli_connect('localhost','root','','book_shop') or die('connection failed');

?>